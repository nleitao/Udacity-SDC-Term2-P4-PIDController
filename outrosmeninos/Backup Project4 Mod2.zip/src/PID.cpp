#include "PID.h"
#include<iostream>

using namespace std;

/*
* TODO: Complete the PID class.
*/

PID::PID() {}

PID::~PID() {}

void PID::Init(double Kpf, double Kif, double Kdf) {

	Kp=Kpf;
	Ki=Kif;
	Kd=Kdf;

  	p_error=0;
  	i_error=0;
  	d_error=0;

}

void PID::UpdateError(double cte) {


d_error=cte-p_error;
p_error=cte;
i_error=i_error+p_error;

// prev_cte=cte;
// int_cte=0;
// diff_cte=cte-prev_cte;
// int_cte+=cte;
// prev_cte=cte;
// steer_value=-Kp*cte-Ki*diff_cte-Kd*int_cte;


// # NOTE: We use params instead of tau_p, tau_d, tau_i
// def run(robot, params, n=100, speed=1.0):
//     x_trajectory = []
//     y_trajectory = []
//     err = 0
//     # TODO: your code here
//     prev_cte = robot.y
//     int_cte = 0
//     for i in range(2 * n):
//         cte = robot.y
//         diff_cte = cte - prev_cte
//         int_cte += cte
//         prev_cte = cte
//         steer = -params[0] * cte - params[1] * diff_cte - params[2] * int_cte
//         robot.move(steer, speed)
//         x_trajectory.append(robot.x)
//         y_trajectory.append(robot.y)
//         if i >= n:
//             err += cte ** 2
//     return x_trajectory, y_trajectory, err / n



}

double PID::TotalError() {

	return sigmoid(-Kp * p_error - Kd * d_error - Ki * i_error);
}

#include <math.h>

double PID::sigmoid(const double value,
                    const double lower,
                    const double upper)
{
    return (upper - lower)/(1 + exp(-value)) + lower;
}