#include <uWS/uWS.h>
#include <iostream>
#include "json.hpp"
#include "PID.h"
#include <math.h>

using namespace std;

// for convenience
using json = nlohmann::json;

// For converting back and forth between radians and degrees.
constexpr double pi() { return M_PI; }
double deg2rad(double x) { return x * pi() / 180; }
double rad2deg(double x) { return x * 180 / pi(); }

// Checks if the SocketIO event has JSON data.
// If there is data the JSON object in string format will be returned,
// else the empty string "" will be returned.
std::string hasData(std::string s) {
  auto found_null = s.find("null");
  auto b1 = s.find_first_of("[");
  auto b2 = s.find_last_of("]");
  if (found_null != std::string::npos) {
    return "";
  }
  else if (b1 != std::string::npos && b2 != std::string::npos) {
    return s.substr(b1, b2 - b1 + 1);
  }
  return "";
}

int main()
{
  uWS::Hub h;



  PID pid;
  


  pid.Init(0.2, 0.004, 3.0);
  // pid.Init(1.1,1.2,1.3);

  double tol=0.2;
  int counter;
  counter=0;





  // TODO: Initialize the pid variable.

  h.onMessage([&pid,&counter](uWS::WebSocket<uWS::SERVER> ws, char *data, size_t length, uWS::OpCode opCode) {
    // "42" at the start of the message means there's a websocket message event.
    // The 4 signifies a websocket message
    // The 2 signifies a websocket event
    if (length && length > 2 && data[0] == '4' && data[1] == '2')
    {
      auto s = hasData(std::string(data).substr(0, length));
      if (s != "") {
        auto j = json::parse(s);
        std::string event = j[0].get<std::string>();
        if (event == "telemetry") {
          // j[1] is the data JSON object
          double cte = std::stod(j[1]["cte"].get<std::string>());
          double speed = std::stod(j[1]["speed"].get<std::string>());
          double angle = std::stod(j[1]["steering_angle"].get<std::string>());
          double steer_value;
          
          // * TODO: Calcuate steering value here, remember the steering value is
          // * [-1, 1].
          // * NOTE: Feel free to play around with the throttle and speed. Maybe use
          // * another PID controller to control the speed!


          // pid.diff_cte=cte-pid.prev_cte;
          // pid.int_cte+=cte;
          // pid.prev_cte=cte;
          
          pid.UpdateError(cte);
          steer_value=-pid.Kp*pid.p_error-pid.Ki*pid.d_error-pid.Kd*pid.i_error;
          steer_value=pid.TotalError();

          // while(steer_value>=1 or steer_value<=-1)
          // {
          //   if(steer_value>=1)
          //   {
          //     steer_value-=0.5;  
          //   }
          //   else
          //     steer_value+=0.5;
            
          // }

          



          // steer_value=0.5;

          // if(cte<=0.7598)
          // {
          // steer_value=cos(acos(0.7598-cte));
          // }
          // else
          // {
          // steer_value=-cos(acos(0.7598-cte)); 
          // }
          

          counter=counter+1;


          // pid.UpdateError(cte);
          // cout<<"hey hop: "<<pid.Kd<<endl;
          // pid.kd=35;
          // cout<<"hey hop: "<<pid.kd<<endl;
          

          //Assuming that being in the middle of the road is CTE=0.7598 (CTE provided when loaded the simulator for the 1st time)

          // pid.p_error+=pow(cte,2);
          // pid.i_error=pid.p_error/counter;

          // pid.p_error=pow(cte-0.7598,2);
          pid.i_error=pid.p_error/counter;

          // int p[3];
          // p[0]=0;
          // p[1]=0;
          // p[2]=0;

          // int dp[3];
          // dp[0]=0.1;
          // dp[1]=0.1;
          // dp[2]=0.1;

          // int it=0;

          // while((dp[0]+dp[1]+dp[2]))>tol
          // {
          //   for(int i=0;i<len(dp);i++)
          //   {
          //     p[i]+=dp[i];


          //   }


          // }

          // while sum(dp) > tol:
          //     print("Iteration {}, best error = {}".format(it, best_err))
          //     for i in range(len(p)):
          //         p[i] += dp[i]
          //         robot = make_robot()
          //         x_trajectory, y_trajectory, err = run(robot, p)

          //         if err < best_err:
          //             best_err = err
          //             dp[i] *= 1.1
          //         else:
          //             p[i] -= 2 * dp[i]
          //             robot = make_robot()
          //             x_trajectory, y_trajectory, err = run(robot, p)

          //             if err < best_err:
          //                 best_err = err
          //                 dp[i] *= 1.1
          //             else:
          //                 p[i] += dp[i]
          //                 dp[i] *= 0.9
          //     it += 1
          // return p





          
          // DEBUG
          std::cout << "CTE: " << cte << " Steering Value: " << steer_value << std::endl;

          json msgJson;
          msgJson["steering_angle"] = steer_value;
          msgJson["throttle"] = 0.3-0.1;
          auto msg = "42[\"steer\"," + msgJson.dump() + "]";
          std::cout << msg << std::endl;
          ws.send(msg.data(), msg.length(), uWS::OpCode::TEXT);
        }
      } else {
        // Manual driving
        std::string msg = "42[\"manual\",{}]";
        ws.send(msg.data(), msg.length(), uWS::OpCode::TEXT);
      }
    }
  });

  // We don't need this since we're not using HTTP but if it's removed the program
  // doesn't compile :-(
  h.onHttpRequest([](uWS::HttpResponse *res, uWS::HttpRequest req, char *data, size_t, size_t) {
    const std::string s = "<h1>Hello world!</h1>";
    if (req.getUrl().valueLength == 1)
    {
      res->end(s.data(), s.length());
    }
    else
    {
      // i guess this should be done more gracefully?
      res->end(nullptr, 0);
    }
  });

  h.onConnection([&h](uWS::WebSocket<uWS::SERVER> ws, uWS::HttpRequest req) {
    std::cout << "Connected!!!" << std::endl;
  });

  h.onDisconnection([&h](uWS::WebSocket<uWS::SERVER> ws, int code, char *message, size_t length) {
    ws.close();
    std::cout << "Disconnected" << std::endl;
  });

  int port = 4567;
  if (h.listen(port))
  {
    std::cout << "Listening to port " << port << std::endl;
  }
  else
  {
    std::cerr << "Failed to listen to port" << std::endl;
    return -1;
  }
  h.run();
}
